CINEVO Node for Windows (x64)
==============================

Loopback-only companion. Binds 127.0.0.1:48184. Never forwards ports.
Never streams media. Plex / Jellyfin tokens stay on this PC.

The executable carries the CINEVO icon and an Authenticode signature
issued as CINEVO for CDXI. It does not request administrator rights.

Install
  Double-click "Install CINEVO Node.bat"
  or: powershell -ExecutionPolicy Bypass -File install.ps1

Then open CINEVO and enter the pairing code shown in the dashboard.

Uninstall
  Quit CINEVO Node from Task Manager, then delete:
  %LOCALAPPDATA%\CINEVO\Node

The program is signed as CINEVO and does not ask for administrator rights.
Windows may show one SmartScreen notice the first time you open it, because
this build is not signed by a paid public certificate. That notice is not a
virus warning. Choose More info, then Run anyway.
